
export default {
    debugLevel: "debug",
    scanPath: "/mnt/d/Projects/Stockfoto\'s/Kick-off 2017",
	recycleBinPath: "/mnt/d/BIN",
	actions: [
    "reorganize",
    //"duplicates",
    //"orphans",
    //"permissions"
  ]
};
