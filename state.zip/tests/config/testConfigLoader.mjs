
import mergedConfig from '../src/modules/configLoader.mjs';

console.log("Merged Configuration:", mergedConfig);
